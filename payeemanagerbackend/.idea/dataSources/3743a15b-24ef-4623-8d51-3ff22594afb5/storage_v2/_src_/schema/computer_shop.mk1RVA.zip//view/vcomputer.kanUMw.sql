create definer = root@localhost view vcomputer as
select `computer_shop`.`brand`.`brand_name`        AS `brand_name`,
       `computer_shop`.`computer_info`.`com_id`    AS `com_id`,
       `computer_shop`.`brand`.`brand_id`          AS `brand_id`,
       `computer_shop`.`cpu`.`cpu_id`              AS `cpu_id`,
       `computer_shop`.`cpu`.`cpu_name`            AS `cpu_name`,
       `computer_shop`.`screen`.`screen_id`        AS `screen_id`,
       `computer_shop`.`screen`.`screen_name`      AS `screen_name`,
       `computer_shop`.`computer_info`.`model`     AS `model`,
       `computer_shop`.`computer_info`.`price`     AS `price`,
       `computer_shop`.`computer_info`.`color`     AS `color`,
       `computer_shop`.`computer_info`.`rel_price` AS `rel_price`,
       `computer_shop`.`computer_info`.`reg_date`  AS `reg_date`,
       `computer_shop`.`computer_info`.`pixels`    AS `pixels`,
       `computer_shop`.`computer_info`.`ram`       AS `ram`,
       `computer_shop`.`computer_info`.`status`    AS `status`,
       `computer_shop`.`computer_info`.`img_path`  AS `img_path`,
       `computer_shop`.`computer_info`.`num`       AS `num`,
       `computer_shop`.`computer_info`.`content`   AS `content`
from (((`computer_shop`.`brand` join `computer_shop`.`computer_info` on ((`computer_shop`.`computer_info`.`brand_id` =
                                                                          `computer_shop`.`brand`.`brand_id`))) join `computer_shop`.`cpu` on ((
        `computer_shop`.`computer_info`.`cpu_id` = `computer_shop`.`cpu`.`cpu_id`)))
         join `computer_shop`.`screen`
              on ((`computer_shop`.`computer_info`.`screen_id` = `computer_shop`.`screen`.`screen_id`)));

-- comment on column vcomputer.status not supported: 0未上架  1上架

