create definer = root@localhost view vsale as
select `computer_shop`.`computer_info`.`com_id`           AS `com_id`,
       `computer_shop`.`computer_info`.`model`            AS `model`,
       `computer_shop`.`computer_info`.`rel_price`        AS `rel_price`,
       sum(`computer_shop`.`order_detail_info`.`account`) AS `count`,
       `computer_shop`.`brand`.`brand_name`               AS `brand_name`
from ((`computer_shop`.`computer_info` left join `computer_shop`.`order_detail_info` on ((
        `computer_shop`.`computer_info`.`com_id` = `computer_shop`.`order_detail_info`.`com_id`)))
         join `computer_shop`.`brand`
              on ((`computer_shop`.`brand`.`brand_id` = `computer_shop`.`computer_info`.`brand_id`)))
group by `computer_shop`.`computer_info`.`com_id`
order by sum(`computer_shop`.`order_detail_info`.`account`) desc;

