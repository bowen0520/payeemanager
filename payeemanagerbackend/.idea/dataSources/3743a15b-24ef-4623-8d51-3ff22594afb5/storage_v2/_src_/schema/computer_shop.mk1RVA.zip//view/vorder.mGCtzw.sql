create definer = root@localhost view vorder as
select `computer_shop`.`user_info`.`user_name`     AS `user_name`,
       `computer_shop`.`user_info`.`user_id`       AS `user_id`,
       `computer_shop`.`user_info`.`age`           AS `age`,
       `computer_shop`.`user_info`.`user_password` AS `user_password`,
       `computer_shop`.`user_info`.`phone`         AS `phone`,
       `computer_shop`.`user_info`.`address`       AS `address`,
       `computer_shop`.`user_info`.`mail`          AS `mail`,
       `computer_shop`.`user_info`.`reg_time`      AS `reg_time`,
       `computer_shop`.`user_info`.`code`          AS `code`,
       `computer_shop`.`user_info`.`rel_name`      AS `rel_name`,
       `computer_shop`.`user_info`.`sex`           AS `sex`,
       `computer_shop`.`user_info`.`Id`            AS `Id`,
       `computer_shop`.`order_info`.`order_id`     AS `order_id`,
       `computer_shop`.`order_info`.`total_price`  AS `total_price`,
       `computer_shop`.`order_info`.`buy_date`     AS `buy_date`,
       `computer_shop`.`order_info`.`ispay`        AS `ispay`,
       `computer_shop`.`order_info`.`isdeliver`    AS `isdeliver`,
       `computer_shop`.`order_info`.`label`        AS `label`,
       `computer_shop`.`order_info`.`tx`           AS `tx`,
       `computer_shop`.`order_info`.`state`        AS `state`,
       `computer_shop`.`user_info`.`status`        AS `status`
from (`computer_shop`.`order_info`
         join `computer_shop`.`user_info`
              on ((`computer_shop`.`user_info`.`user_id` = `computer_shop`.`order_info`.`user_id`)));

-- comment on column vorder.ispay not supported: 支付 0没有  1 已支付

-- comment on column vorder.isdeliver not supported: 发货 0 没有 1发货

-- comment on column vorder.label not supported: 说明

-- comment on column vorder.state not supported: 信息默认存在为1，不存在为0

