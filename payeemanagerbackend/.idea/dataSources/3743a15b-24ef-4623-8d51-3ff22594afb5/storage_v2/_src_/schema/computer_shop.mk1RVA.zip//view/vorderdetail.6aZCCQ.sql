create definer = root@localhost view vorderdetail as
select `computer_shop`.`computer_info`.`com_id`              AS `com_id`,
       `computer_shop`.`computer_info`.`brand_id`            AS `brand_id`,
       `computer_shop`.`computer_info`.`model`               AS `model`,
       `computer_shop`.`computer_info`.`color`               AS `color`,
       `computer_shop`.`computer_info`.`price`               AS `price`,
       `computer_shop`.`computer_info`.`rel_price`           AS `rel_price`,
       `computer_shop`.`computer_info`.`img_path`            AS `img_path`,
       `computer_shop`.`computer_info`.`reg_date`            AS `reg_date`,
       `computer_shop`.`computer_info`.`pixels`              AS `pixels`,
       `computer_shop`.`computer_info`.`cpu_id`              AS `cpu_id`,
       `computer_shop`.`computer_info`.`screen_id`           AS `screen_id`,
       `computer_shop`.`computer_info`.`ram`                 AS `ram`,
       `computer_shop`.`computer_info`.`num`                 AS `num`,
       `computer_shop`.`computer_info`.`content`             AS `content`,
       `computer_shop`.`cpu`.`cpu_name`                      AS `cpu_name`,
       `computer_shop`.`screen`.`screen_name`                AS `screen_name`,
       `computer_shop`.`brand`.`brand_name`                  AS `brand_name`,
       `computer_shop`.`order_detail_info`.`order_detail_id` AS `order_detail_id`,
       `computer_shop`.`order_detail_info`.`order_id`        AS `order_id`,
       `computer_shop`.`order_detail_info`.`buy_price`       AS `buy_price`,
       `computer_shop`.`order_detail_info`.`account`         AS `account`,
       `computer_shop`.`order_info`.`total_price`            AS `total_price`,
       `computer_shop`.`order_info`.`buy_date`               AS `buy_date`,
       `computer_shop`.`order_info`.`ispay`                  AS `ispay`,
       `computer_shop`.`order_info`.`isdeliver`              AS `isdeliver`,
       `computer_shop`.`order_info`.`label`                  AS `label`,
       `computer_shop`.`user_info`.`user_id`                 AS `user_id`,
       `computer_shop`.`user_info`.`age`                     AS `age`,
       `computer_shop`.`user_info`.`user_name`               AS `user_name`,
       `computer_shop`.`user_info`.`user_password`           AS `user_password`,
       `computer_shop`.`user_info`.`phone`                   AS `phone`,
       `computer_shop`.`user_info`.`address`                 AS `address`,
       `computer_shop`.`user_info`.`mail`                    AS `mail`,
       `computer_shop`.`user_info`.`reg_time`                AS `reg_time`,
       `computer_shop`.`user_info`.`code`                    AS `code`,
       `computer_shop`.`user_info`.`rel_name`                AS `rel_name`,
       `computer_shop`.`user_info`.`sex`                     AS `sex`,
       `computer_shop`.`user_info`.`Id`                      AS `Id`
from ((((((`computer_shop`.`computer_info` join `computer_shop`.`order_detail_info` on ((
        `computer_shop`.`order_detail_info`.`com_id` =
        `computer_shop`.`computer_info`.`com_id`))) join `computer_shop`.`order_info` on ((
        `computer_shop`.`order_info`.`order_id` =
        `computer_shop`.`order_detail_info`.`order_id`))) join `computer_shop`.`user_info` on ((
        `computer_shop`.`user_info`.`user_id` =
        `computer_shop`.`order_info`.`user_id`))) join `computer_shop`.`cpu` on ((`computer_shop`.`cpu`.`cpu_id` =
                                                                                  `computer_shop`.`computer_info`.`cpu_id`))) join `computer_shop`.`screen` on ((
        `computer_shop`.`screen`.`screen_id` = `computer_shop`.`computer_info`.`screen_id`)))
         join `computer_shop`.`brand`
              on ((`computer_shop`.`brand`.`brand_id` = `computer_shop`.`computer_info`.`brand_id`)));

-- comment on column vorderdetail.ispay not supported: 支付 0没有  1 已支付

-- comment on column vorderdetail.isdeliver not supported: 发货 0 没有 1发货

-- comment on column vorderdetail.label not supported: 说明

